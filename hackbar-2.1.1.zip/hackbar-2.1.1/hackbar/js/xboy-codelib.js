php_module = {
    php_protocol: function(options){
        var options = options
        var txt;
        switch(options){
            case 'php_filter':
                txt = 'php://filter/read=convert.base64-encode/resource=xxx';
                break;

            case 'php_file':
                txt = 'file://';
                break;

            case 'php_input':
                txt = 'php://input';
                break;
            case 'php_data':
                txt = 'data://text/plain,xxx';
                break;
            case 'some_usage':
                txt = './usage.html';
                break;
        }
        return txt;
    }
}



function search_keyword(keyword){
    var res = [];
    if(keyword.length == 0){
        return res;
    }

    for(var i = 0;i < payload_list.length;i++ ){
        if((payload_list[i]).indexOf(keyword) == 0){
            res.push(payload_list[i]);
        }
    }
    return res;
}



function create_input_from_data(auto_value,form_id){
    var postData = getPostData();
    if (typePostdata === "formdata") {
            
        for (var i = 0; i < postData.length; i++) {
            var field = postData[i].substr(0, postData[i].indexOf('='));
            var fieldvalue = postData[i].substr(postData[i].indexOf('=') + 1);
            if (fieldvalue.indexOf('*') != -1){
                fieldvalue = auto_value;
            }
            create_input(field,fieldvalue,form_id);
        }
        return 1;

    }else{
        return 0;
        }
}

function check_data(dataString){
    if (dataString.indexOf('*') == -1){
        alert('please use * choose auto param');
        return 1;
    }
}


function check_url(url){
    if (url.length == 0){
        alert('please input url');
        return 1;
    }
}
